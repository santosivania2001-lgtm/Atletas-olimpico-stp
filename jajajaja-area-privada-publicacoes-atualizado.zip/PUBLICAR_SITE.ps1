$ErrorActionPreference = 'Stop'
$siteRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$cliPath = Join-Path $env:LOCALAPPDATA 'npm-cache\_npx\f2d227eedb70bbb2\node_modules\firebase-tools\lib\bin\firebase.js'
$authDirectory = Join-Path $siteRoot '.firebase-cli-auth-20261111'
$authDirectoryCreated = $false
$authorizationCode = $null
$result = 1

try {
  if (-not (Test-Path -LiteralPath $cliPath)) {
    throw 'A ferramenta Firebase CLI não está disponível neste computador.'
  }
  if (Test-Path -LiteralPath $authDirectory) {
    throw 'Já existe uma pasta temporária de autenticação. Não foi alterada; fecha a publicação anterior e tenta novamente.'
  }

  New-Item -ItemType Directory -Path $authDirectory | Out-Null
  $authDirectoryCreated = $true
  $env:XDG_CONFIG_HOME = $authDirectory
  $env:FIREBASE_CLI_DISABLE_UPDATE_CHECK = '1'
  $env:FIREBASE_CLI_DISABLE_USAGE_REPORTING = '1'

  Write-Host 'A iniciar a autenticação oficial do Firebase...'
  $loginLines = & node.exe --max-old-space-size=1024 $cliPath login --reauth --no-localhost 2>&1
  $loginText = ($loginLines | Out-String)
  Write-Host $loginText
  if ($LASTEXITCODE -ne 0) {
    throw 'Não foi possível iniciar a autenticação. Confirma a ligação à internet e tenta de novo.'
  }

  $urlMatch = [regex]::Match($loginText, 'https://auth\.firebase\.tools/login[^\s\x1b]+')
  if (-not $urlMatch.Success) {
    throw 'O Firebase não forneceu a ligação temporária de autenticação.'
  }

  Write-Host 'Abri a página de autenticação. Inicia sessão na conta Google com acesso ao projeto e copia o código mostrado.'
  Start-Process -FilePath $urlMatch.Value -WindowStyle Normal
  $authorizationCode = Read-Host 'Cola o código apenas nesta janela (não o envies por mensagem)'
  if ([string]::IsNullOrWhiteSpace($authorizationCode)) {
    throw 'Não foi inserido nenhum código de autenticação.'
  }

  & node.exe --max-old-space-size=1024 $cliPath login $authorizationCode
  if ($LASTEXITCODE -ne 0) {
    throw 'O Firebase não aceitou a autenticação. Tenta novamente com um código novo.'
  }

  Write-Host 'A publicar o site no Firebase Hosting...'
  & node.exe --max-old-space-size=1024 $cliPath deploy --only hosting --project teste-114ef
  if ($LASTEXITCODE -ne 0) {
    throw 'O Firebase não concluiu a publicação. Lê a mensagem acima.'
  }

  $result = 0
  Write-Host 'Publicação concluída.'
} catch {
  Write-Host $_.Exception.Message -ForegroundColor Red
} finally {
  $authorizationCode = $null
  if ($authDirectoryCreated -and (Test-Path -LiteralPath $authDirectory)) {
    $rootFull = [System.IO.Path]::GetFullPath($siteRoot).TrimEnd('\') + '\'
    $authFull = [System.IO.Path]::GetFullPath($authDirectory)
    if ($authFull.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
      Remove-Item -LiteralPath $authFull -Recurse -Force
    }
  }
}

exit $result
