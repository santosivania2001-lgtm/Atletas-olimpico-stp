@echo off
setlocal
cd /d "%~dp0"
set "PORT="
for %%P in (8000 8001 8002 8003) do call :check_port %%P
if not defined PORT (
  echo Nao foi possivel encontrar uma porta livre entre 8000 e 8003.
  pause
  exit /b 1
)
where python >nul 2>nul
if not errorlevel 1 goto usar_python
where py >nul 2>nul
if not errorlevel 1 goto usar_py
echo Python nao foi encontrado. Instale o Python 3 para iniciar o site.
pause
exit /b 1
:usar_python
echo O site sera aberto em http://localhost:%PORT%/admin.html
echo Mantenha esta janela aberta enquanto usa o site.
start "" /min powershell.exe -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://localhost:%PORT%/admin.html'"
python -m http.server %PORT% --bind 127.0.0.1
pause
exit /b %errorlevel%
:usar_py
echo O site sera aberto em http://localhost:%PORT%/admin.html
echo Mantenha esta janela aberta enquanto usa o site.
start "" /min powershell.exe -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://localhost:%PORT%/admin.html'"
py -3 -m http.server %PORT% --bind 127.0.0.1
pause
exit /b %errorlevel%
:check_port
if defined PORT exit /b
netstat -ano | findstr /R /C:":%~1 .*LISTENING" >nul 2>nul
if errorlevel 1 set "PORT=%~1"
exit /b

